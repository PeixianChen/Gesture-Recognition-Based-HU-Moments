﻿#include "GestureRecognition.h"
#include "FunctionTools.h"
#include "CompareImage.h"

const char* path;

// 构造函数
Gesture::Gesture(Mat& image)
{
	_imgRaw = image.clone();
	_contours = vector<Contour>();
	HaveForearm = false;
}

// 显示原图
void Gesture::Show()
{
	imshow("原图", _imgRaw);
	//imshow("二值图", _imgBin);
}

// 将imgRaw转换为二值图，并存储在imgBin中
void Gesture::_GetBinaryImage(Mat& imgBin)
{

	 //灰度图
	cvtColor(_imgRaw, imgBin, CV_BGR2GRAY);
	//图像增强

	//滤波
	//bilateralFilter(imgBin,imgBin,3,5,3);
	// 膨胀
	dilate(imgBin, imgBin, Mat(5, 5, CV_8UC1), Point(-1, -1));
	// 腐蚀
	erode(imgBin, imgBin, Mat(5, 5, CV_8UC1), Point(-1, -1));
	// 二值化
	threshold(imgBin, imgBin, 10, 255, 0);
	medianBlur(imgBin,imgBin,9);
}

// 返回某个轮廓集合中，面积最大的轮廓的下标
int Gesture::_MaxContourIndex(vector<Contour>& contours)
{

	// 该轮廓必须非空
	assert(!contours.empty());

	double maxArea = -1;
	int idxMax = -1;
	for (int i = 0; i < (int)contours.size(); i++)
	{
		double thisArea = contourArea(contours[i]);
		if (thisArea > maxArea)
		{
			maxArea = thisArea;
			idxMax = i;
		}
	}
	// 必须返回正确下标
	assert(idxMax >= 0);
	assert(idxMax < (int)contours.size());
	return idxMax;
}

// 返回某个轮廓内最大圆的圆心P及半径R
void Gesture::_MaxCircleInContour(const Contour& contour, Point& P, double& R)
{
	P = Point(-1, -1);
	R = -1;
	for (int i = 0; i < _imgBin.rows; i += 40)
		for (int j = 0; j < _imgBin.cols; j += 40)
			if (_imgBin.at<uchar>(i, j) == 255)
			{
				double minDist = 1e66;
				for (int k = 0; k < (int)contour.size(); k += 4)
				{
					double thisDist = dist2(contour[k], Point(j, i));
					if (thisDist < minDist)
					{
						minDist = thisDist;
					}
				}
				if (R < minDist)
				{
					R = minDist;
					P = Point(j, i);
				}
			}
	if (R > 0) R = sqrtf(R);
}

// 返回轮廓是否与边界接触
bool Gesture::_TouchedWithBoundary(const Contour& contour, int maxRow, int maxCol)
{
	int fixed = 5;
	for(int i=0;i<(int)contour.size();i++)
	{
		const Point &p = contour[i];
		if(p.x < fixed || p.x > maxCol-fixed || p.y < fixed || p.y > maxRow-fixed)
			return 1;
	}
	return 0;
}
//寻找手腕点
void Gesture::GetPalmPoint(const Contour& newContours, Point P, int index,int maxRow, int maxCol)
{
    _FingerTips.clear();
    int fixed = 6;
    int num = 0;
    int FirstPoint = -1;//最新手腕坐标
    int sz_con = newContours.size();
	if(index == 0 || index == 2)
    {
        for(int i = 0;i<sz_con-1;i++)
            {
                if(abs(newContours[i].y  - P.y) <= fixed && abs(newContours[i+1].y - P.y) > fixed )
                {
                    if(FirstPoint == -1)
                    {
                        _FingerTips.push_back(newContours[i]);
                        ForeamrPoint.push_back(newContours[i]);
                        _FingerTipsindex.push_back(i);
                        FirstPoint = i;
                        num++;
                        if(num == 2)
                            break;
                    }
                    else
                    {
                        if(abs(i - FirstPoint) > 5)
                        {
                            _FingerTips.push_back(newContours[i]);
                            ForeamrPoint.push_back(newContours[i]);
                            _FingerTipsindex.push_back(i);
                            FirstPoint= i;
                            num++;
                            if(num == 2)
                                break;
                        }
                    }
                }
                else if(abs(newContours[i+1].y  - P.y) <= fixed && abs(newContours[i].y - P.y) > fixed)
                    if(FirstPoint == -1)
                    {
                        _FingerTips.push_back(newContours[i+1]);
                        ForeamrPoint.push_back(newContours[i+1]);
                        _FingerTipsindex.push_back(i+1);
                        FirstPoint= i+1;
                        num++;
                        if(num == 2)
                            break;
                    }
                    else
                    {
                        if(abs(i + 1 - FirstPoint) > 8)
                        {
                            _FingerTips.push_back(newContours[i+1]);
                            ForeamrPoint.push_back(newContours[i+1]);
                            _FingerTipsindex.push_back(i+1);
                            FirstPoint = i+1;
                            num++;
                            if(num == 2)
                                break;
                        }
                    }
                }
                if(num < 2)
                {
                    if( abs(newContours[0].y  - P.y) <= fixed && abs(newContours[sz_con-1].y - P.y) > fixed)
                    {
                        _FingerTips.push_back(newContours[0]);
                        ForeamrPoint.push_back(newContours[0]);
                        _FingerTipsindex.push_back(0);
                        FirstPoint = 0;
                    }
                    else if(abs(newContours[sz_con-1].y  - P.y) <= fixed && abs(newContours[0].y - P.y) > fixed)
                    {
                        _FingerTips.push_back(newContours[sz_con-1]);
                        ForeamrPoint.push_back(newContours[sz_con-1]);
                        _FingerTipsindex.push_back(sz_con-1);
                        FirstPoint = sz_con-1;
                    }
                }
    }
    else if(index == 1 || index == 3)
    {
        for(int i = 0;i<sz_con-1;i++)
            {
                if(abs(newContours[i].x  - P.x) <= fixed && abs(newContours[i+1].x - P.x) > fixed )
                {
                    if(FirstPoint == -1)
                    {
                        _FingerTips.push_back(newContours[i]);
                        ForeamrPoint.push_back(newContours[i]);
                        _FingerTipsindex.push_back(i);
                        FirstPoint = i;
                        num++;
                        if(num == 2)
                            break;
                    }
                    else
                    {
                        if(abs(i - FirstPoint) > 5)
                        {
                            _FingerTips.push_back(newContours[i]);
                            ForeamrPoint.push_back(newContours[i]);
                            _FingerTipsindex.push_back(i);
                            FirstPoint= i;
                            num++;
                            if(num == 2)
                                break;
                        }
                    }
                }
                else if(abs(newContours[i+1].x  - P.x) <= fixed && abs(newContours[i].x - P.x) > fixed)
                    if(FirstPoint == -1)
                    {
                        _FingerTips.push_back(newContours[i+1]);
                        ForeamrPoint.push_back(newContours[i+1]);
                        _FingerTipsindex.push_back(i+1);
                        FirstPoint= i+1;
                        num++;
                        if(num == 2)
                            break;
                    }
                    else
                    {
                        if(abs(i + 1 - FirstPoint) > 8)
                        {
                            _FingerTips.push_back(newContours[i+1]);
                            ForeamrPoint.push_back(newContours[i+1]);
                            _FingerTipsindex.push_back(i+1);
                            FirstPoint = i+1;
                            num++;
                            if(num == 2)
                                break;
                        }
                    }
                }
                if(num < 2)
                {
                    if( abs(newContours[0].x  - P.x) <= fixed && abs(newContours[sz_con-1].x - P.x) > fixed)
                    {
                        _FingerTips.push_back(newContours[0]);
                        ForeamrPoint.push_back(newContours[0]);
                        _FingerTipsindex.push_back(0);
                        FirstPoint = 0;
                    }
                    else if(abs(newContours[sz_con-1].x  - P.x) <= fixed && abs(newContours[0].x - P.x) > fixed)
                    {
                        _FingerTips.push_back(newContours[sz_con-1]);
                        ForeamrPoint.push_back(newContours[sz_con-1]);
                        _FingerTipsindex.push_back(sz_con-1);
                        FirstPoint = sz_con-1;
                    }
                }
    }
    for(int i=0;i<ForeamrPoint.size();i++)
    {
		circle(_imgRaw,ForeamrPoint[i],10,Scalar(255,255,255),-1);
    }

}
//增加点数
// 寻找手掌
bool Gesture::GetPalmImage()
{

	// 二值化
	_GetBinaryImage(_imgBin);

	// 在二值图中找出所有的轮廓
	Mat imgBin = _imgBin.clone();
	findContours(imgBin, _contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);

	// 若没有轮廓，返回false
	if (_contours.empty())
	{
		std::cerr << "[错误] 未找到轮廓。" << std::endl;
		return false;
	}
	//// 【蓝色】所有找到的轮廓
	//drawContours(_imgRaw, _contours, -1, Scalar(255, 0, 0), 2, 8);

	// 找到最大的轮廓（手）
	int idxMax = _MaxContourIndex(_contours);
	//// 【绿色】手的轮廓
	//drawContours(_imgRaw, _contours, 0, Scalar(0, 255, 0), 2, 8);

	// 在二值图中画出填充的最大轮廓
	_imgBin = Mat::zeros(_imgRaw.rows, _imgRaw.cols, CV_8UC1);
	drawContours(_imgBin, _contours, idxMax, Scalar(255, 255, 255), -1, 8);
	// 找到轮廓内最大圆的圆心P及半径R
	Point P;
	double R;
	_MaxCircleInContour(_contours[idxMax], P, R);
	if (R < 0)
	{
		std::cerr << "[错误] 未找到圆心及半径。" << std::endl;
		return false;
	}

	// 记录中心点及半径
	_Center = P;
	_CenterRadius = R;

	//画外接矩阵

	Rect rect2 = boundingRect(_contours[idxMax]);
	rectangle(_imgRaw,rect2,Scalar(255,0,0),3);
	Point tl = rect2.tl();
	Point br = rect2.br();

//利用外接矩阵切割手掌{
	int index = -1;
	Point indexPoint;
	if(br.y >= _imgRaw.rows - 5)
	{
		rect2.width = abs(tl.y - P.y) + 1.5 * R;
		indexPoint = rect2.br();;
		index = 0;
	}
	else if (br.x >= _imgRaw.cols - 5)
	{
		rect2.width = abs(tl.x - P.x) + 1.5 * R;
		indexPoint = rect2.br();;
		index = 1;
	}
	else if(tl.x <= 5)
	{
		rect2.x = (br.x - P.x);
		rect2.width = (br.x - P.x); + 1.5 * R;
		indexPoint = rect2.tl();
		index = 2;
	}
	else if(tl.y <= 5)
	{
		rect2.x = (br.y - P.y);
		rect2.width = (br.y - P.y); +1.5 *  R;
		indexPoint = rect2.tl();
		index = 3;
	}
	rectangle(_imgRaw,rect2,Scalar(255,255,0),3);
//}利用外接矩阵切割手掌

	
	// 用背景色（黑色）填充手掌矩形
	imgBin = _imgBin.clone();
	rectangle(imgBin,rect2,Scalar(0,0,0),-1);

	// 【紫色】最大圆及圆心
	circle(_imgRaw, P, (int)R, Scalar(255, 0, 255), 4);
	circle(_imgRaw, P, 10, Scalar(255, 0, 255), -1);

	// 寻找此时imgBin中的轮廓
	vector<Contour> newContours;
	findContours(imgBin, newContours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);
	if (newContours.empty())
	{
		std::cerr << "[错误] 填充矩形后，未找到轮廓。" << std::endl;
		imgBin = _imgBin.clone();
		_contours.clear();
		findContours(imgBin, _contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
		// 【红色】手掌轮廓
		drawContours(_imgRaw, _contours, 0, Scalar(0, 0, 255), 4, 8);

		if(br.y >= _imgRaw.rows - 5 || br.x >= _imgRaw.cols - 5)
			indexPoint = br;
		else if(tl.x <= 5 || tl.y <= 5)	
			indexPoint = tl;
		GetPalmPoint(_contours[0],indexPoint,index,_imgRaw.rows,_imgRaw.cols);
		AddPoint();

		return false;
	}

	// 删除所有与边界接触，且面积大于阈值的轮廓下标
	// 删除方式为，在内部二值图，用黑色填充
	double area_level = acos(-1) * R * R * 0.25;
	Contour deleteContour = _contours[idxMax];
	for(int i=0;i<(int)newContours.size();i++)
	{
		Contour &thisContour = newContours[i];
		if(_TouchedWithBoundary(thisContour, imgBin.rows, imgBin.cols))// && contourArea(thisContour) > area_level)
		{
			HaveForearm  = true;
			drawContours(_imgBin, newContours, i, Scalar(0, 0, 0), -1, 8);
			deleteContour = thisContour;
		}
	}

	// 再次寻找手轮廓
	imgBin = _imgBin.clone();
	_contours.clear();
	findContours(imgBin, _contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);

	if (_contours.size() != 1u)
	{
		std::cerr << "[错误] 再次寻找手轮廓时出错，此时应该有且只有一个轮廓。" << std::endl;
		return false;
	}
	if (_contours[0].empty())
	{
		std::cerr << "[错误] 再次寻找手轮廓时出错，找到唯一一个轮廓但是为空。" << std::endl;
		return false;
	}

	// 【红色】手掌轮廓
	drawContours(_imgRaw, _contours, 0, Scalar(0, 0, 255), 4, 8);
	//寻找手腕点
	GetPalmPoint(_contours[0],indexPoint,index,_imgRaw.rows,_imgRaw.cols);
	AddPoint();

	return true;
}

// 寻找指尖
void Gesture::FindFingerTips()
{
	// 寻找指尖
	Contour &contourPoints = _contours[0];
	_FingerTips.clear();
	int firInd=0;   //the  index of first landmark
	int FirstPoint = 0,num = 0;

	// 寻找每一个角度较大的点
	vector<int> idxs;
	vector<int> Firstindex;//第一个点群
	int pStep = 16;
	for (int i = 0; i < (int)contourPoints.size(); i++)
	{
		// 选取一定间隔的三个点
		int j = (i + pStep) % contourPoints.size();
		int k = (i + pStep * 2) % contourPoints.size();
		Point &p1 = contourPoints[i];
		Point &p2 = contourPoints[j];
		Point &p3 = contourPoints[k];

		// 构成两个向量
		Point vec_p1p2 = Point(p2.x - p1.x, p2.y - p1.y);
		Point vec_p2p3 = Point(p3.x - p2.x, p3.y - p2.y);

		// 计算夹角
		double dot = vec_p1p2.x * vec_p2p3.x + vec_p1p2.y * vec_p2p3.y;
		double xmult = vec_p1p2.x * vec_p2p3.y - vec_p1p2.y * vec_p2p3.x;
		double len_vec_p1p2 = sqrtf(dist2(p1, p2));
		double len_vec_p2p3 = sqrtf(dist2(p2, p3));
		double cos_val = 1. * dot / len_vec_p1p2 / len_vec_p2p3;
		double angle = acos(cos_val) / acos(-1) * 180;

		

		// 符合要求则将p2的下标存入idxs
		// 余弦值小于0.3 叉积方向为逆时针 位于最大圆外侧
		if (cos_val < 0.3 && xmult < 0/*&& (sqrtf(dist2(_Center, p2)) > _CenterRadius * 2 + 2 || sqrtf(dist2(_Center, p2)) > _CenterRadius * 2 - 2)*/)
		{
			//cout<<j<<endl;
			//circle(_imgRaw,contourPoints[j],5,Scalar(0,255,255),-1);
			// idxs为空时直接放入
			if(idxs.empty())
			{
				idxs.push_back(j);
			}
			// 否则判断与上一点的下标是否变化过大
			else
			{
				int pre_idx = *idxs.rbegin();
				// 过大 则判定当前idxs为一个指尖集合
				if((j - pre_idx +contourPoints.size())%contourPoints.size() > 10)
				{
					//cout<<"------------"<<"j:"<<j<<"  pre:"<<pre_idx<<endl;
					int idx_middle = idxs[idxs.size() / 2];
					/*if(sqrtf(dist2(contourPoints[idx_middle],ForeamrPoint[0]))>100 && sqrtf(dist2(contourPoints[idx_middle],ForeamrPoint[1]))>100)
					{*/
						if(FirstPoint == 0)
						{
							FirstPoint = idx_middle;
							firInd=idx_middle;   //the  index of first landmark
							Firstindex = idxs;
						}
						else
						{
							_FingerTips.push_back(contourPoints[idx_middle]);
							_FingerTipsindex.push_back(idx_middle);
							circle(_imgRaw, contourPoints[idx_middle], 8, Scalar(0, 255, 0), -1);	
						}
	
					//}
					idxs.clear();
					idxs.push_back(j);
				}
				// 否则继续添加
				else
				{
					idxs.push_back(j);
				}
			}
		}
	}

	// 处理idxs非空的情况
	bool hebing = false;//判断首尾点集是否可以合并
	if(!idxs.empty() && !Firstindex.empty())
	{
		int idx_middle;
		int sz_idx = idxs.size();
		int ze_fir = Firstindex.size();
		/*cout<<"size"<<contourPoints.size()<<endl;
		cout<<"idx:"<<idxs[sz_idx-1]<<endl;
		cout<<"fir:"<<Firstindex[ze_fir-1]<<endl;*/
		if(abs(idxs[sz_idx-1] - Firstindex[0])<=pStep)
		{
			//cout<<"hebing1"<<endl;
			hebing = true;
			int x = (sz_idx +ze_fir)/2;
			if( x > sz_idx)
			{
				idx_middle = Firstindex[x - 1 - sz_idx];
			}
			else
			{
				idx_middle = idxs[x-1];
			}
		}
		else
		{
			idx_middle = idxs[sz_idx / 2];
		}
		/*if(sqrtf(dist2(contourPoints[idx_middle],ForeamrPoint[0]))>100 && sqrtf(dist2(contourPoints[idx_middle],ForeamrPoint[1]))>100)
		{*/
			_FingerTips.push_back(contourPoints[idx_middle]);
			_FingerTipsindex.push_back(idx_middle);
			circle(_imgRaw, contourPoints[idx_middle], 8, Scalar(0, 255, 0), -1);
			num ++;
		//}
	}
	if (idxs.empty() ||  !hebing)
	{
		//cout<<"hebing2"<<endl;
		_FingerTips.push_back(contourPoints[firInd]);
		_FingerTipsindex.push_back(firInd);
		circle(_imgRaw, contourPoints[firInd], 8, Scalar(0, 255, 0), -1);
	}
	idxs.clear();
	//circle(_imgRaw,contourPoints[0],5,Scalar(0,0,255),-1);
	//circle(_imgRaw,contourPoints[contourPoints.size()-1],5,Scalar(255,0,255),-1);
	////  【绿色】画出所有的指尖
	//for (int i = 0; i < (int)_FingerTips.size(); i++)
	//{
	//	circle(_imgRaw, _FingerTips[i], 5, Scalar(255, 255, 0), -1);
	//}

}

// 增加判断点
void Gesture::AddPoint()
{

    Contour &contourPoints = _contours[0];

	int sz = contourPoints.size();//手的轮廓大小
	//增加特征点
	int sz_finger = _FingerTipsindex.size();//手腕点作为起点
	int last = _FingerTipsindex[_FingerTipsindex.size() - 1];//手腕点作为终点

    int FirstPoint = last;
    int idx_middle = _FingerTipsindex[0];
	int temp_fir_idx=(int)((idx_middle - FirstPoint + sz)%sz/21.0);

    for (int tem=1; tem<21;tem++)
    {
		//cout<<FirstPoint + temp_fir_idx*tem<<" ";
		_FingerTips.push_back(contourPoints[(FirstPoint + temp_fir_idx*tem) % sz]);
		_FingerTipsindex.push_back((FirstPoint+temp_fir_idx*tem)%sz);
        circle(_imgRaw, contourPoints[(FirstPoint + temp_fir_idx*tem) % sz], 5, Scalar(255, 255, 0), -1);                         
    }
}
double Gesture:: GetCenterRadius()
{
	return _CenterRadius;
}

//输出图片识别结果
void Gesture::SetText(string& txt)
{
	putText(_imgRaw, txt, _Center,CV_FONT_HERSHEY_COMPLEX, 1, Scalar(0, 0, 255) );
}
Mat Gesture::GetImg()
{
	return _imgRaw;
}

Mat Gesture::GetBinary()
{
	return _imgBin;
}
// 返回中心点
Point Gesture::GetCenterPoint()
{
	return _Center;
}

// 返回指尖点
vector<Point> Gesture::GetFingerTipPoints()
{
	return _FingerTips;
}
double Gesture::GetDist()
{
	return dist;
}

// 析构函数
Gesture::~Gesture()
{
	_imgRaw.release();
	_imgBin.release();
}
