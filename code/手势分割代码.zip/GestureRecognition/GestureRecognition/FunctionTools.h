#pragma once
#include <opencv2/opencv.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"

using namespace cv;

// ��������cv::Point֮������ƽ��
double dist2(const Point &a, const Point &b) {
	return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}
// ���ص㵽����ߵľ���
void distrect2(const Point &P,const Rect rect, double RectDist[] )
{
	Point tl = rect.tl();
	Point br = rect.br();
	RectDist[0] += abs(P.y - tl.y) + abs(P.x - (br.x - tl.x)/2);
	RectDist[1] += abs(P.y - br.y) + abs(P.x - (br.x - tl.x)/2);
	RectDist[2] += abs(P.x - tl.x) + abs(P.y - (br.y - tl.y)/2);
	RectDist[3] += abs(P.x - br.x) + abs(P.y - (br.y - tl.y)/2);
}
void distrect(const Point &P,Point2f vertices[], double RectDist[] )
{
	double a[4],b[4],c[4];
	Point mindelPoint[4];
	for (int i = 0; i < 4; i++)  
	{
		a[i] = (vertices[i].y - vertices[(i + 1) % 4].y)/(vertices[i].x - vertices[(i + 1) % 4].x);
		b[i] = -1;
		c[i] = - a[i] * vertices[(i + 1) % 4].x + vertices[(i + 1) % 4].y;
		mindelPoint[i].x = abs(vertices[i].x - vertices[(i + 1) % 4].x) / 2;
		mindelPoint[i].y = abs(vertices[i].y - vertices[(i + 1) % 4].y) / 2;
	}
	RectDist[0] += abs(a[0] * P.x + b[0] * P.y + c[0]) / sqrt(a[0]*a[0] + b[0]*b[0]);
	//ͶӰ�����꣺
	Point PP;
	PP.x = (-a[0] * P.x + c[0]) / a[0] * 2;
	PP.y = -a[0] * (PP.x - P.x);
	RectDist[0] += sqrt(dist2(PP,mindelPoint[0]));

	RectDist[1] += abs(a[1] * P.x + b[1] * P.y + c[1]) / sqrt(a[1]*a[1] + b[1]*b[1]);
	PP.x = (-a[1] * P.x + c[1]) / a[1] * 2;
	PP.y = -a[1] * (PP.x - P.x);
	RectDist[1] += sqrt(dist2(PP,mindelPoint[1]));

	RectDist[2] += abs(a[2] * P.x + b[2] * P.y + c[2]) / sqrt(a[2]*a[2] + b[2]*b[2]);
	PP.x = (-a[2] * P.x + c[2]) / a[2] * 2;
	PP.y = -a[2] * (PP.x - P.x);
	RectDist[2] += sqrt(dist2(PP,mindelPoint[2]));

	RectDist[3] += abs(a[3] * P.x + b[3] * P.y + c[3]) / sqrt(a[3]*a[3] + b[3]*b[3]);
	PP.x = (-a[3] * P.x + c[3]) / a[3] * 2;
	PP.y = -a[3] * (PP.x - P.x);
	RectDist[3] += sqrt(dist2(PP,mindelPoint[3]));
}