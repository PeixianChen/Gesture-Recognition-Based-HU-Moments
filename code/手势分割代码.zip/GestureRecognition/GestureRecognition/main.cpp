#define _CRT_SECURE_NO_WARNINGS
#include "GestureRecognition.h"
#include <ctime>
#include <iostream>
#include <ctime>
#include <math.h>
#include <fstream>

using namespace std;

/************************************
InvariantMoment.cpp

Calculate the Invariant Moment.
Obtain the distance of the Invariant Moment between two images

Author: Han Yuexing

Date: 2015-06

*************************************/
/*
1.Load image
2.Convert to gray-scale.
3.Remove noise by blurring with a Gaussian filter 
4.Detect edges using canny
5.Find contours (findContours)
6.Get the moments(Moments)
7.Draw contours 
8.Calculate the area with the moments 00 and compare with the result of the OpenCV function
*/


/*
Illustration: 
	Caculate the distance between two images (binary edge) with the method of Invariant Moment
Input: 
	bkImgEdge1, bkImgEdge2: binary edge images
Output:
	distMoments: the distance between bkImgEdge1 and bkImgEdge2 with the method of Invariant Moment
return:
	0: OK
 */
void DistTwoMoments(Mat bkImgEdge1,ofstream& myfile)
{
	Moments mymoments1;
       
	double hu1[7];
	

	mymoments1 = moments(bkImgEdge1,0); 

	HuMoments(mymoments1, hu1);
	for(int i=0;i<4;i++)
	{
		myfile<<hu1[i]<<" ";
	}
//	cout<<hu1[0]<<"/"<<hu1[1]<<"/"<<hu1[2]<<"/"<<hu1[3]<<"/"<<hu1[4]<<"/"<<hu1[5]<<"/"<<hu1[6]<<"/"<<"/"<<endl;

}

double Dist2(const Point &a, const Point &b) {
	return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

int main()
{
		/*clock_t start,finish; 
		Mat frame = imread("../result/test/3.1.jpg");*/

		 ofstream myfile("../result/HandText_pca5_5.txt",ios::out);  //example.txt����Ҫ������ļ�������
		if(!myfile)
		{
			cout<<"error !";
		}

		Mat imgBin;
		char buf[10];
		for(int i=1;i<21;i++)
		{
			sprintf(buf, "%d.png", i);
			string Image_name2 = buf;
			string InputImageFile2 = "../result/Hand/3_"+Image_name2;
			Mat test = imread(InputImageFile2);
			if(test.empty())
			{
				cout<<"û��ͼƬ"<<endl;
			}


			Gesture GestureObj(test);
			GestureObj.GetPalmImage();
			imgBin = GestureObj.GetBinary();

			GestureObj.Show();
			waitKey(0);

			//HU��
			//DistTwoMoments(imgBin,myfile);
			//vector<vector<Point>> contours;
			////Rect rect;
			//Mat _imgBin = imgBin.clone();
			//findContours(_imgBin, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE);

			//�������ܳ������
			//double length = arcLength(contours[0],1);
			//double area = contourArea(contours[0]);
			//double five = length / area;
			//myfile<<five<<" ";
			//myfile<<"\n";

			//����20����������뾶�ľ����

			vector<Point> f = GestureObj.GetFingerTipPoints();
			Point C = GestureObj.GetCenterPoint();
			double R = GestureObj.GetCenterRadius();

			double d = sqrt(Dist2(C,f[18]));
			double result = d/R;
			myfile<<result<<" ";
			for(int i=2;i<f.size();i++)
			{
				double d = sqrt(Dist2(C,f[i]));
				double result = d/R;
				myfile<<result<<" ";
			}
			myfile<<"\n";
		}

		myfile.close();
	system("pause");
	return 0;
}


